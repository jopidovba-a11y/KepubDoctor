package com.example.kepubdoctor

import android.content.Context
import android.net.Uri
import java.io.File

enum class OutputFormat { EPUB, KEPUB }

class EpubStructureException(message: String) : Exception(message)

data class ProcessResult(
    val report: FixReport,
    val workDir: File,
    val orderedEntries: List<String>,
    val suggestedFileName: String
)

object EpubProcessor {

    private const val WORK_DIR_PREFIX = "kepubdoctor_work_"
    private const val TEMP_ZIP_PREFIX = "kepubdoctor_temp_"

    fun process(
        context: Context,
        inputUri: Uri,
        outputFormat: OutputFormat,
        customPhrases: List<String> = emptyList(),
        addBookStyle: Boolean = false
    ): ProcessResult {
        val workDir = File(context.cacheDir, "$WORK_DIR_PREFIX${System.currentTimeMillis()}")
        workDir.mkdirs()
        val tempZipFile = File(context.cacheDir, "$TEMP_ZIP_PREFIX${System.currentTimeMillis()}.zip")

        try {
            val orderedEntries: List<String> = context.contentResolver.openInputStream(inputUri).use { input ->
                requireNotNull(input) { "Could not open the file" }
                ZipUtils.extract(input, workDir, tempZipFile)
            }
            tempZipFile.delete()

            DrmDetector.checkForDrm(workDir)

            val report = EpubFixer.fixAll(workDir, customPhrases, addBookStyle)

            if (report.fixes.any { it.startsWith("ERROR:") }) {
                throw EpubStructureException(
                    "This file could not be processed: " +
                    report.fixes.first { it.startsWith("ERROR:") }
                )
            }

            ImageOptimizer.optimize(workDir, report)

            val originalName = getFileName(context, inputUri) ?: "book.epub"
            val suggestedName: String

            if (outputFormat == OutputFormat.KEPUB) {
                KepubConverter.convertAll(workDir)
                report.fixes.add("Converted to KEPUB format (Kobo spans injected)")
                suggestedName = KepubConverter.kepubOutputFileName(originalName)
            } else {
                suggestedName = originalName.replace(Regex("\\.epub$", RegexOption.IGNORE_CASE), "") + "_healed.epub"
            }

            return ProcessResult(report, workDir, orderedEntries, suggestedName)
        } catch (e: Throwable) {
            // Don't leave a half-processed copy of the book in the cache.
            workDir.deleteRecursively()
            throw e
        } finally {
            tempZipFile.delete()
        }
    }

    fun writeResult(result: ProcessResult, outputStream: java.io.OutputStream) {
        ZipUtils.repackage(result.workDir, outputStream, result.orderedEntries)
    }

    fun cleanup(result: ProcessResult) {
        result.workDir.deleteRecursively()
    }

    /** Deletes work files left behind by earlier sessions (older than one hour, so a running job is never touched). */
    fun cleanupStale(context: Context) {
        val cutoff = System.currentTimeMillis() - 60 * 60 * 1000L
        context.cacheDir.listFiles()
            ?.filter { it.name.startsWith(WORK_DIR_PREFIX) || it.name.startsWith(TEMP_ZIP_PREFIX) }
            ?.filter { it.lastModified() < cutoff }
            ?.forEach { it.deleteRecursively() }
    }

    private fun getFileName(context: Context, uri: Uri): String? {
        var name: String? = null
        context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
            val idx = cursor.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
            if (idx != -1 && cursor.moveToFirst()) {
                name = cursor.getString(idx)
            }
        }
        return name
    }
}
