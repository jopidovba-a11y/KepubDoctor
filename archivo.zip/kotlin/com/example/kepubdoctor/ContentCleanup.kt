package com.example.kepubdoctor

import java.io.File

object ContentCleanup {

    fun fixAll(epubDir: File, report: FixReport) {
        var count = 0
        epubDir.walkTopDown()
            .filter { it.isFile && (it.extension == "xhtml" || it.extension == "html" || it.extension == "htm") }
            .forEach { file ->
                val original = file.readText()
                var cleaned = original

                cleaned = cleaned.replace("\uFFFD", "")
                // Empty server-side-include markers left behind by some sites (Cloudflare)
                cleaned = cleaned.replace("<!--sse-->", "").replace("<!--/sse-->", "")
                cleaned = cleaned.replace(Regex("</?o:p[^>]*>"), "")
                cleaned = cleaned.replace(Regex("</?w:[^>]*>"), "")
                cleaned = cleaned.replace(Regex("mso-[\\w-]+\\s*:[^;\"]*;?"), "")

                if (cleaned != original) {
                    file.writeText(cleaned)
                    count++
                }
            }
        if (count > 0) report.fixes.add("$count file(s) cleaned of Unicode replacement characters, MS Word leftovers and empty site comments")
    }
}