package com.example.kepubdoctor

import org.jsoup.Jsoup
import org.jsoup.parser.Parser
import java.io.File

class DrmProtectedException(message: String) : Exception(message)

object DrmDetector {

    // encryption.xml is also used by DRM-free books to obfuscate embedded fonts.
    // These two algorithms are font obfuscation (IDPF and Adobe), not DRM.
    private val FONT_OBFUSCATION_ALGORITHMS = setOf(
        "http://www.idpf.org/2008/embedding",
        "http://ns.adobe.com/pdf/enc#RC"
    )

    fun checkForDrm(epubDir: File) {
        val encryptionFile = File(epubDir, "META-INF/encryption.xml")
        if (encryptionFile.exists() && !onlyObfuscatesFonts(encryptionFile)) {
            throw DrmProtectedException(
                "This EPUB is DRM-protected (META-INF/encryption.xml was found). " +
                "KepubDoctor cannot repair or convert DRM-protected books."
            )
        }
        val rightsFile = File(epubDir, "META-INF/rights.xml")
        if (rightsFile.exists()) {
            throw DrmProtectedException(
                "This EPUB is DRM-protected (META-INF/rights.xml was found). " +
                "KepubDoctor cannot repair or convert DRM-protected books."
            )
        }
    }

    /** True only if every encrypted resource uses a font obfuscation algorithm. Anything unclear counts as DRM. */
    private fun onlyObfuscatesFonts(file: File): Boolean {
        return try {
            val doc = Jsoup.parse(file.readText(), "", Parser.xmlParser())
            // Tags may carry a namespace prefix (e.g. "enc:EncryptionMethod").
            val algorithms = doc.allElements.toList()
                .filter { it.tagName().substringAfter(':').equals("EncryptionMethod", ignoreCase = true) }
                .map { it.attr("Algorithm").trim() }
            algorithms.isNotEmpty() && algorithms.all { it in FONT_OBFUSCATION_ALGORITHMS }
        } catch (e: Exception) {
            false
        }
    }
}
