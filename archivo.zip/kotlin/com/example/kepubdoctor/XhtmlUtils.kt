package com.example.kepubdoctor

import org.jsoup.Jsoup
import org.jsoup.nodes.Comment
import org.jsoup.nodes.Document
import org.jsoup.nodes.Element
import org.jsoup.nodes.Entities
import java.io.File

object XhtmlUtils {

    private val LEADING_XML_DECL = Regex("""^\uFEFF?\s*<\?xml[^>]*\?>\s*""")

    // Matches href="file.xhtml#some-id" / src="...#some-id" (also valid for NCX and OPF files).
    private val FRAGMENT_REF = Regex("""(?:href|src)\s*=\s*["'][^"']*#([^"']+)["']""", RegexOption.IGNORE_CASE)
    private val LINKABLE_EXTENSIONS = setOf("xhtml", "html", "htm", "ncx", "opf")

    fun parse(rawContent: String): Document {
        val withoutDecl = rawContent.replace(LEADING_XML_DECL, "")
        val doc = Jsoup.parse(withoutDecl)
        removeBogusXmlDeclarationComments(doc)
        return doc
    }

    private fun removeBogusXmlDeclarationComments(doc: Document) {
        doc.childNodes().filterIsInstance<Comment>()
            .filter { it.data.trim().startsWith("?xml") }
            .forEach { it.remove() }
        doc.select("html, head").forEach { el ->
            el.childNodes().filterIsInstance<Comment>()
                .filter { it.data.trim().startsWith("?xml") }
                .forEach { it.remove() }
        }
    }

    fun serialize(doc: Document): String {
        doc.outputSettings()
            .syntax(Document.OutputSettings.Syntax.xml)
            .escapeMode(Entities.EscapeMode.xhtml)
            .charset(Charsets.UTF_8)
        return "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n" + doc.html()
    }

    /** Percent-decodes a string (e.g. "Chapter%201" -> "Chapter 1") without turning '+' into a space. */
    fun percentDecode(value: String): String {
        return try {
            java.net.URLDecoder.decode(value.replace("+", "%2B"), "UTF-8")
        } catch (e: Exception) {
            value
        }
    }

    /**
     * Resolves a manifest/container href to a file on disk. Hrefs are URLs, so names with spaces or
     * special characters appear percent-encoded ("Chapter%201.xhtml") while the file on disk is
     * "Chapter 1.xhtml". Tries the decoded path first and falls back to the literal one.
     */
    fun resolveHref(baseDir: File, href: String): File {
        val cleanHref = href.substringBefore('#').substringBefore('?')
        val decoded = File(baseDir, percentDecode(cleanHref))
        if (decoded.exists()) return decoded
        val literal = File(baseDir, cleanHref)
        return if (literal.exists()) literal else decoded
    }

    /** Collects every fragment id that some link points to ("page.xhtml#id") anywhere in the book. */
    fun collectReferencedIds(epubDir: File): Set<String> {
        val ids = HashSet<String>()
        epubDir.walkTopDown()
            .filter { it.isFile && it.extension.lowercase() in LINKABLE_EXTENSIONS }
            .forEach { file ->
                FRAGMENT_REF.findAll(file.readText()).forEach { match ->
                    val raw = match.groupValues[1]
                    ids.add(raw)
                    ids.add(percentDecode(raw))
                }
            }
        return ids
    }

    /** True if the element, or any element inside it, has an id that some link points to. */
    fun containsReferencedId(el: Element, referencedIds: Set<String>): Boolean {
        return el.getAllElements().any { it.id().isNotEmpty() && it.id() in referencedIds }
    }
}
