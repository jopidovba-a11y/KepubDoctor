package com.example.kepubdoctor

import org.jsoup.nodes.Element
import org.jsoup.nodes.TextNode
import java.io.File

object ItalicSpaceFixer {

    private val TARGET_TAGS = setOf("i", "em", "b", "strong")

    fun fixAll(epubDir: File, report: FixReport) {
        var fixedCount = 0
        var filesAffected = 0

        epubDir.walkTopDown()
            .filter { it.isFile && (it.extension == "xhtml" || it.extension == "html" || it.extension == "htm") }
            .forEach { file ->
                val original = file.readText()
                val doc = XhtmlUtils.parse(original)
                var fileChanged = false

                for (tagName in TARGET_TAGS) {
                    for (el in doc.select(tagName)) {
                        // Move the space right after the closing tag inside it (at the end)
                        val nextSibling = el.nextSibling()
                        if (nextSibling is TextNode) {
                            val text = nextSibling.text()
                            if (text.isNotEmpty() && text[0] == ' ' && !text.startsWith("  ")) {
                                nextSibling.text(text.substring(1))
                                appendSpaceInside(el)
                                fixedCount++
                                fileChanged = true
                            }
                        }

                        // Move the space right before the opening tag inside it (at the start)
                        val prevSibling = el.previousSibling()
                        if (prevSibling is TextNode) {
                            val text = prevSibling.text()
                            if (text.isNotEmpty() && text.last() == ' ' && !text.endsWith("  ")) {
                                prevSibling.text(text.substring(0, text.length - 1))
                                prependSpaceInside(el)
                                fixedCount++
                                fileChanged = true
                            }
                        }
                    }
                }

                if (fileChanged) {
                    filesAffected++
                    file.writeText(XhtmlUtils.serialize(doc))
                }
            }

        if (fixedCount > 0) {
            report.fixes.add("$fixedCount space(s) next to italic/bold moved inside the tag")
        }
    }

    private fun appendSpaceInside(el: Element) {
        val lastChild = el.childNodes().lastOrNull()
        if (lastChild is TextNode) {
            lastChild.text(lastChild.text() + " ")
        } else {
            el.appendChild(TextNode(" "))
        }
    }

    private fun prependSpaceInside(el: Element) {
        val firstChild = el.childNodes().firstOrNull()
        if (firstChild is TextNode) {
            firstChild.text(" " + firstChild.text())
        } else {
            el.prependChild(TextNode(" "))
        }
    }
}