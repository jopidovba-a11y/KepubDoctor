package com.example.kepubdoctor

import org.jsoup.Jsoup
import org.jsoup.nodes.Document
import org.jsoup.parser.Parser
import java.io.File

object NavNcxFixer {

    fun fixAll(opfFile: File, report: FixReport) {
        if (!opfFile.exists()) return
        val doc = Jsoup.parse(opfFile.readText(), "", Parser.xmlParser())
        val opfDir = opfFile.parentFile ?: return

        val version = doc.select("package").firstOrNull()?.attr("version")?.trim() ?: "2.0"
        val isEpub3 = version.startsWith("3")

        val spineIdrefs = doc.select("spine itemref").map { it.attr("idref") }
        if (spineIdrefs.isEmpty()) return

        val chapters = spineIdrefs.mapNotNull { idref ->
            val item = doc.select("manifest item[id=\"$idref\"]").firstOrNull() ?: return@mapNotNull null
            val href = item.attr("href")
            // The blank cover page we insert ourselves does not belong in the table of contents.
            if (File(href).name == TitlepageFixer.DUMMY_FILENAME) return@mapNotNull null
            val file = XhtmlUtils.resolveHref(opfDir, href)
            val title = if (file.exists()) extractTitle(file) else href
            href to title
        }
        if (chapters.isEmpty()) return

        if (isEpub3) ensureNav(doc, opfFile, opfDir, chapters, report)
        else ensureNcx(doc, opfFile, opfDir, chapters, report)
    }

    private fun extractTitle(file: File): String {
        val html = Jsoup.parse(file.readText())
        val h = html.select("h1, h2, h3, title").firstOrNull()?.text()?.trim()
        return if (!h.isNullOrBlank()) h else file.nameWithoutExtension
    }

    private fun ensureNav(doc: Document, opfFile: File, opfDir: File, chapters: List<Pair<String, String>>, report: FixReport) {
        val navItem = doc.select("manifest item[properties~=nav]").firstOrNull()
        val navFile = navItem?.let { XhtmlUtils.resolveHref(opfDir, it.attr("href")) }
        if (navItem != null && navFile != null && navFile.exists()) return

        val navFileName = "kepubdoctor-nav.xhtml"
        val listItems = chapters.joinToString("\n") { (href, title) ->
            "      <li><a href=\"${escapeXml(href)}\">${escapeXml(title)}</a></li>"
        }
        File(opfDir, navFileName).writeText(
            """<?xml version="1.0" encoding="UTF-8"?>
<html xmlns="http://www.w3.org/1999/xhtml" xmlns:epub="http://www.idpf.org/2007/ops">
<head><title>Table of Contents</title></head>
<body>
  <nav epub:type="toc" id="toc">
    <ol>
$listItems
    </ol>
  </nav>
</body>
</html>"""
        )

        navItem?.remove()
        val manifest = doc.select("manifest").firstOrNull() ?: return
        val newItem = doc.createElement("item")
        newItem.attr("id", "kepubdoctor-nav")
        newItem.attr("href", navFileName)
        newItem.attr("media-type", "application/xhtml+xml")
        newItem.attr("properties", "nav")
        manifest.appendChild(newItem)

        opfFile.writeText(doc.outerHtml())
        report.fixes.add("nav.xhtml (EPUB3 table of contents) generated/repaired")
    }

    private fun ensureNcx(doc: Document, opfFile: File, opfDir: File, chapters: List<Pair<String, String>>, report: FixReport) {
        val spine = doc.select("spine").firstOrNull() ?: return
        val tocId = spine.attr("toc")
        val ncxItem = if (tocId.isNotBlank()) doc.select("manifest item[id=\"$tocId\"]").firstOrNull() else null
        val ncxFile = ncxItem?.let { XhtmlUtils.resolveHref(opfDir, it.attr("href")) }
        if (ncxItem != null && ncxFile != null && ncxFile.exists()) return

        val ncxFileName = "kepubdoctor-toc.ncx"
        val navPoints = chapters.mapIndexed { i, (href, title) ->
            """    <navPoint id="navpoint-${i + 1}" playOrder="${i + 1}">
      <navLabel><text>${escapeXml(title)}</text></navLabel>
      <content src="${escapeXml(href)}"/>
    </navPoint>"""
        }.joinToString("\n")
        val uid = doc.select("dc|identifier, identifier").firstOrNull()?.text() ?: "unknown-id"

        File(opfDir, ncxFileName).writeText(
            """<?xml version="1.0" encoding="UTF-8"?>
<ncx xmlns="http://www.daisy.org/z3986/2005/ncx/" version="2005-1">
  <head>
    <meta name="dtb:uid" content="${escapeXml(uid)}"/>
  </head>
  <docTitle><text>Table of Contents</text></docTitle>
  <navMap>
$navPoints
  </navMap>
</ncx>"""
        )

        ncxItem?.remove()
        val manifest = doc.select("manifest").firstOrNull() ?: return
        val newItem = doc.createElement("item")
        newItem.attr("id", "kepubdoctor-ncx")
        newItem.attr("href", ncxFileName)
        newItem.attr("media-type", "application/x-dtbncx+xml")
        manifest.appendChild(newItem)
        spine.attr("toc", "kepubdoctor-ncx")

        opfFile.writeText(doc.outerHtml())
        report.fixes.add("toc.ncx (EPUB2 table of contents) generated/repaired")
    }

    private fun escapeXml(text: String): String = text
        .replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
        .replace("\"", "&quot;").replace("'", "&apos;")
}
