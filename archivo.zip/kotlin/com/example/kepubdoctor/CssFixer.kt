package com.example.kepubdoctor

import java.io.File

object CssFixer {

    private val LOCKING_PROPS = listOf(
        "margin", "margin-top", "margin-bottom", "margin-left", "margin-right",
        "padding", "padding-top", "padding-bottom", "padding-left", "padding-right",
        "width", "height", "max-width", "max-height", "min-width", "min-height"
    )

    private val SAFE_SELECTORS = setOf("html", "body", "@page")

    fun fixAll(epubDir: File, report: FixReport) {
        var cssFilesFixed = 0
        var xhtmlFixed = 0

        epubDir.walkTopDown()
            .filter { it.isFile && it.extension.equals("css", ignoreCase = true) }
            .forEach { file ->
                val original = file.readText()
                val cleaned = stripLockingRulesFromStylesheet(original, SAFE_SELECTORS)
                if (cleaned != original) {
                    file.writeText(cleaned)
                    cssFilesFixed++
                }
            }

        epubDir.walkTopDown()
            .filter { it.isFile && (it.extension == "xhtml" || it.extension == "html" || it.extension == "htm") }
            .forEach { file ->
                val original = file.readText()
                val cleaned = fixXhtmlInlineCss(original, SAFE_SELECTORS)
                if (cleaned != original) {
                    file.writeText(cleaned)
                    xhtmlFixed++
                }
            }

        if (cssFilesFixed > 0) report.fixes.add("$cssFilesFixed CSS stylesheet(s) fixed (fixed margin/width removed from html/body/@page only)")
        if (xhtmlFixed > 0) report.fixes.add("$xhtmlFixed XHTML file(s) fixed (inline styles on html/body)")
    }

    fun stripLockingRulesFromStylesheet(css: String, safeSelectors: Set<String>): String {
        val noComments = css.replace(Regex("/\\*.*?\\*/", RegexOption.DOT_MATCHES_ALL), "")
        val blockRegex = Regex("""([^{}]+)\{([^{}]*)\}""")
        return blockRegex.replace(noComments) { match ->
            val selectorPart = match.groupValues[1]
            val declarations = match.groupValues[2]

            val matches = selectorPart.split(",").any { piece ->
                piece.trim().lowercase() in safeSelectors
            }

            if (matches) "$selectorPart{${stripDeclarations(declarations)}}" else match.value
        }
    }

    private fun stripDeclarations(declarations: String): String {
        return declarations.split(";")
            .map { it.trim() }
            .filter { decl ->
                if (decl.isEmpty()) return@filter true
                decl.substringBefore(":").trim().lowercase() !in LOCKING_PROPS
            }
            .joinToString(";")
    }

    fun fixXhtmlInlineCss(content: String, safeSelectors: Set<String>): String {
        val doc = XhtmlUtils.parse(content)

        doc.select("style").forEach { styleTag ->
            val cleaned = stripLockingRulesFromStylesheet(styleTag.data(), safeSelectors)
            if (cleaned != styleTag.data()) styleTag.text(cleaned)
        }

        listOf(doc.select("html").firstOrNull(), doc.body()).forEach { el ->
            if (el != null && el.hasAttr("style")) {
                val cleanedStyle = stripDeclarations(el.attr("style"))
                if (cleanedStyle.isBlank()) el.removeAttr("style") else el.attr("style", cleanedStyle)
            }
        }

        return XhtmlUtils.serialize(doc)
    }
}