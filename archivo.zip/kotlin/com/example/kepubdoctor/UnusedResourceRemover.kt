package com.example.kepubdoctor

import org.jsoup.Jsoup
import org.jsoup.parser.Parser
import java.io.File

/**
 * Removes images, fonts and stylesheets that are listed in the manifest but that nothing in the book
 * references. Conservative on purpose: when in doubt, the file stays.
 */
object UnusedResourceRemover {

    private val REMOVABLE_MEDIA = Regex(
        "^(image/(jpeg|jpg|png|gif|svg\\+xml|webp|bmp)|text/css|font/.*|" +
            "application/(font-.*|x-font-.*|vnd\\.ms-opentype|vnd\\.ms-fontobject))$",
        RegexOption.IGNORE_CASE
    )
    private val TEXT_EXTENSIONS = setOf("xhtml", "html", "htm", "css", "svg", "ncx")

    private val ATTR_REF = Regex("""(?:src|href|data|poster)\s*=\s*["']([^"']+)["']""", RegexOption.IGNORE_CASE)
    private val SRCSET_REF = Regex("""srcset\s*=\s*["']([^"']+)["']""", RegexOption.IGNORE_CASE)
    private val CSS_URL_REF = Regex("""url\(\s*["']?([^)"']+)["']?\s*\)""", RegexOption.IGNORE_CASE)
    private val CSS_IMPORT_REF = Regex("""@import\s+["']([^"']+)["']""", RegexOption.IGNORE_CASE)
    private val ENCRYPTION_URI = Regex("""URI\s*=\s*["']([^"']+)["']""", RegexOption.IGNORE_CASE)
    private val EXTERNAL_REF = Regex("^[a-zA-Z][a-zA-Z0-9+.-]*:")

    private const val MAX_PASSES = 5

    fun fixAll(epubDir: File, opfFile: File, report: FixReport) {
        try {
            removeUnused(epubDir, opfFile, report)
        } catch (e: Exception) {
            // Never fail the whole job because of an optimization: keep every file.
        }
    }

    private fun removeUnused(epubDir: File, opfFile: File, report: FixReport) {
        if (!opfFile.exists()) return
        val doc = Jsoup.parse(opfFile.readText(), "", Parser.xmlParser())
        val opfDir = opfFile.parentFile ?: return

        val coverMetaId = doc.select("meta[name=cover]").firstOrNull()?.attr("content")?.trim().orEmpty()

        val candidates = doc.select("manifest item").toList().filter { item ->
            val href = item.attr("href")
            val id = item.attr("id")
            REMOVABLE_MEDIA.matches(item.attr("media-type").trim()) &&
                !href.startsWith("http", ignoreCase = true) &&
                !item.attr("properties").contains("cover-image") &&
                !(coverMetaId.isNotEmpty() && id == coverMetaId) &&
                !id.contains("cover", ignoreCase = true) &&
                !href.contains("cover", ignoreCase = true)
        }.mapNotNull { item ->
            val file = XhtmlUtils.resolveHref(opfDir, item.attr("href"))
            if (file.exists()) item to file else null
        }
        if (candidates.isEmpty()) return

        // Files named by META-INF/encryption.xml (obfuscated fonts) must stay.
        val protectedPaths = HashSet<String>()
        File(epubDir, "META-INF/encryption.xml").takeIf { it.exists() }?.let { enc ->
            ENCRYPTION_URI.findAll(enc.readText()).forEach { m ->
                canonical(File(epubDir, XhtmlUtils.percentDecode(m.groupValues[1])))?.let { protectedPaths.add(it) }
            }
        }

        var removedCount = 0
        var removedBytes = 0L
        val alive = candidates.toMutableList()

        repeat(MAX_PASSES) {
            val referenced = collectReferences(epubDir, doc, opfDir)
            val orphans = alive.filter { (_, file) ->
                val path = canonical(file)
                path != null && path !in referenced && path !in protectedPaths
            }
            if (orphans.isEmpty()) return@repeat
            for ((item, file) in orphans) {
                removedBytes += file.length()
                if (file.delete()) {
                    item.remove()
                    removedCount++
                }
                alive.remove(item to file)
            }
        }

        if (removedCount > 0) {
            opfFile.writeText(doc.outerHtml())
            report.fixes.add("$removedCount unused file(s) removed (images/fonts/stylesheets that nothing references, ${removedBytes / 1024} KB)")
        }
    }

    private fun collectReferences(epubDir: File, opfDoc: org.jsoup.nodes.Document, opfDir: File): Set<String> {
        val refs = HashSet<String>()

        fun add(baseDir: File, raw: String) {
            val clean = raw.trim().substringBefore('#').substringBefore('?')
            if (clean.isEmpty() || EXTERNAL_REF.containsMatchIn(clean)) return
            val base = if (clean.startsWith("/")) epubDir else baseDir
            val relative = clean.trimStart('/')
            canonical(File(base, XhtmlUtils.percentDecode(relative)))?.let { refs.add(it) }
            canonical(File(base, relative))?.let { refs.add(it) }
        }

        // <guide> references may point at images (cover)
        opfDoc.select("guide reference").forEach { add(opfDir, it.attr("href")) }

        epubDir.walkTopDown()
            .filter { it.isFile && it.extension.lowercase() in TEXT_EXTENSIONS }
            .forEach { file ->
                val dir = file.parentFile ?: epubDir
                val text = file.readText()
                ATTR_REF.findAll(text).forEach { add(dir, it.groupValues[1]) }
                SRCSET_REF.findAll(text).forEach { m ->
                    m.groupValues[1].split(",").forEach { part -> add(dir, part.trim().substringBefore(' ')) }
                }
                CSS_URL_REF.findAll(text).forEach { add(dir, it.groupValues[1]) }
                CSS_IMPORT_REF.findAll(text).forEach { add(dir, it.groupValues[1]) }
            }
        return refs
    }

    // Lower-cased so a link that differs from the file name only by letter case still counts as a reference.
    private fun canonical(file: File): String? =
        try { file.canonicalPath.lowercase() } catch (e: Exception) { null }
}
