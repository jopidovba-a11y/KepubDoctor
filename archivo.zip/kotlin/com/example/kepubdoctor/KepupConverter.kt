package com.example.kepubdoctor

import org.jsoup.nodes.Document
import org.jsoup.nodes.Element
import org.jsoup.nodes.Node
import org.jsoup.nodes.TextNode
import java.io.File

object KepubConverter {

    private val SKIP_TAGS = setOf("script", "style", "pre", "code", "select",
        "textarea", "video", "audio", "iframe", "svg", "math", "head", "title",
        "rt", "rp")

    fun convertAll(epubDir: File, smartenPunctuation: Boolean = true) {
        epubDir.walkTopDown()
            .filter { it.isFile && (it.extension == "xhtml" || it.extension == "html" || it.extension == "htm") }
            .forEach { file ->
                val content = file.readText()
                file.writeText(convertXhtml(content, smartenPunctuation))
            }
    }

    fun convertXhtml(content: String, smartenPunctuation: Boolean): String {
        val doc = XhtmlUtils.parse(content)

        stripExistingKepubArtifacts(doc)

        val body = doc.body() ?: return XhtmlUtils.serialize(doc)

        val paragraphCounter = intArrayOf(1)
        wrapNode(body, paragraphCounter, smartenPunctuation)
        wrapBodyInKoboContainers(doc, body)

        return XhtmlUtils.serialize(doc)
    }

    private fun stripExistingKepubArtifacts(doc: Document) {
        doc.select("span.koboSpan").forEach { span ->
            span.unwrap()
        }
        doc.select("#book-inner").forEach { it.unwrap() }
        doc.select("#book-columns").forEach { it.unwrap() }

        doc.body()?.let { mergeAdjacentTextNodes(it) }
    }

    private fun mergeAdjacentTextNodes(root: Node) {
        for (child in root.childNodes().toList()) {
            if (child is Element) mergeAdjacentTextNodes(child)
        }
        var children = root.childNodes()
        var i = 0
        while (i < children.size - 1) {
            val a = children[i]
            val b = children[i + 1]
            if (a is TextNode && b is TextNode) {
                a.text(a.wholeText + b.wholeText)
                b.remove()
                children = root.childNodes()
            } else {
                i++
            }
        }
    }

    private fun wrapBodyInKoboContainers(doc: Document, body: Element) {
        val children = body.childNodes().toList()

        val bookInner = doc.createElement("div").apply { attr("id", "book-inner") }
        for (child in children) {
            child.remove()
            bookInner.appendChild(child)
        }

        val bookColumns = doc.createElement("div").apply { attr("id", "book-columns") }
        bookColumns.appendChild(bookInner)

        body.appendChild(bookColumns)
    }

    private fun wrapNode(node: Node, paragraphCounter: IntArray, smartenPunctuation: Boolean) {
    val children = node.childNodes().toList()
    for (child in children) {
        when (child) {
            is TextNode -> {
                val originalText = child.text()
                if (originalText.isNotBlank()) {
                    val rawText = if (smartenPunctuation) smarten(originalText) else originalText

                    // Preserve the whitespace at the node edges BEFORE splitting into sentences,
                    // because splitIntoSentences() discards it when no text follows it inside
                    // the same node (root cause of the "glued text" bug).
                    val leadingWs = rawText.takeWhile { it.isWhitespace() }
                    val trailingWs = rawText.takeLastWhile { it.isWhitespace() }
                    val segments = splitIntoSentences(rawText)

                    var anchor: Node = child

                    if (leadingWs.isNotEmpty()) {
                        val leadNode = TextNode(leadingWs)
                        anchor.after(leadNode)
                        anchor = leadNode
                    }

                    var segIndex = 1
                    for ((i, seg) in segments.withIndex()) {
                        val s = Element("span")
                        s.addClass("koboSpan")
                        s.attr("id", "kobo.${paragraphCounter[0]}.$segIndex")
                        s.text(seg)
                        anchor.after(s)
                        anchor = s
                        segIndex++

                        if (i < segments.size - 1) {
                            val spaceNode = TextNode(" ")
                            anchor.after(spaceNode)
                            anchor = spaceNode
                        }
                    }

                    if (trailingWs.isNotEmpty()) {
                        val trailNode = TextNode(trailingWs)
                        anchor.after(trailNode)
                        anchor = trailNode
                    }

                    child.remove()
                    paragraphCounter[0]++
                }
            }
            is Element -> {
                if (child.tagName().lowercase() !in SKIP_TAGS) {
                    wrapNode(child, paragraphCounter, smartenPunctuation)
                }
            }
            else -> { /* comments, etc.: ignore */ }
        }
    }
}
    private fun splitIntoSentences(text: String): List<String> {
        val regex = Regex("(?<=[.!?])\\s+")
        return text.split(regex).map { it.trim() }.filter { it.isNotEmpty() }
    }

    fun smarten(text: String): String {
        var t = text

        t = t.replace("...", "\u2026")
        t = t.replace("---", "\u2014")
        t = t.replace("--", "\u2013")

        t = t.replace(Regex("(^|[\\s(\\[{])\""), "$1\u201C")
        t = t.replace("\"", "\u201D")

        t = t.replace(Regex("(^|[\\s(\\[{])'"), "$1\u2018")
        t = t.replace("'", "\u2019")

        return t
    }

    fun kepubOutputFileName(originalName: String): String {
        val base = originalName
            .replace(Regex("\\.epub$", RegexOption.IGNORE_CASE), "")
            .replace(Regex("\\.kepub$", RegexOption.IGNORE_CASE), "")
        return "${base}_healed.kepub.epub"
    }
}