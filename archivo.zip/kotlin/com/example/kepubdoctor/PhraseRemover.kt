package com.example.kepubdoctor

import org.jsoup.nodes.Element
import java.io.File

object PhraseRemover {

    private val BLOCK_TAGS = setOf("p", "div", "li", "blockquote", "td", "h1", "h2", "h3", "h4", "h5", "h6")
    private val UNWRAPPABLE_INLINE_TAGS = setOf("a", "span", "em", "strong", "b", "i", "u", "small", "font")

    fun fixAll(epubDir: File, phrases: List<String>, report: FixReport) {
        val cleanPhrases = phrases.map { it.trim() }.filter { it.isNotEmpty() }
        if (cleanPhrases.isEmpty()) return

        var occurrencesRemoved = 0
        var filesAffected = 0

        epubDir.walkTopDown()
            .filter { it.isFile && (it.extension == "xhtml" || it.extension == "html" || it.extension == "htm") }
            .forEach { file ->
                val original = file.readText()
                val doc = XhtmlUtils.parse(original)
                var fileChanged = false

                // 1. Simple case: the phrase is fully contained in a single text node.
                doc.allElements.forEach { el ->
                    for (textNode in el.textNodes().toList()) {
                        var text = textNode.text()
                        var textChanged = false
                        for (phrase in cleanPhrases) {
                            if (text.contains(phrase)) {
                                occurrencesRemoved += text.split(phrase).size - 1
                                text = text.replace(phrase, "")
                                textChanged = true
                            }
                        }
                        if (textChanged) {
                            textNode.text(text)
                            fileChanged = true
                        }
                    }
                }

                // 2. Split case: the phrase is spread across several nodes/tags
                //    (e.g. a URL wrapped in <a>). Search the whole block.
                for (blockTag in BLOCK_TAGS) {
                    for (block in doc.select(blockTag)) {
                        val combinedText = block.text()
                        val matchedPhrase = cleanPhrases.firstOrNull { combinedText.contains(it) } ?: continue

                        // Unwrap inline tags inside the block so the text can be merged
                        for (tag in UNWRAPPABLE_INLINE_TAGS) {
                            block.select(tag).forEach { it.unwrap() }
                        }
                        mergeAdjacentTextNodesIn(block)

                        for (textNode in block.textNodes().toList()) {
                            var text = textNode.text()
                            if (text.contains(matchedPhrase)) {
                                occurrencesRemoved++
                                text = text.replace(matchedPhrase, "")
                                textNode.text(text)
                                fileChanged = true
                            }
                        }
                    }
                }

                if (fileChanged) {
                    filesAffected++
                    file.writeText(XhtmlUtils.serialize(doc))
                }
            }

        if (occurrencesRemoved > 0) {
            report.fixes.add("$occurrencesRemoved occurrence(s) of custom phrase(s) removed in $filesAffected file(s)")
        }
    }

    private fun mergeAdjacentTextNodesIn(root: Element) {
        for (child in root.childNodes().toList()) {
            if (child is Element) mergeAdjacentTextNodesIn(child)
        }
        var children = root.childNodes()
        var i = 0
        while (i < children.size - 1) {
            val a = children[i]
            val b = children[i + 1]
            if (a is org.jsoup.nodes.TextNode && b is org.jsoup.nodes.TextNode) {
                a.text(a.wholeText + b.wholeText)
                b.remove()
                children = root.childNodes()
            } else {
                i++
            }
        }
    }
}