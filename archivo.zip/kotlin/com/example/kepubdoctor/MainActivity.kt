package com.example.kepubdoctor

import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.CompoundButton
import android.widget.EditText
import android.widget.ProgressBar
import android.widget.RadioGroup
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : AppCompatActivity() {

    private var selectedUri: Uri? = null
    private var lastResult: ProcessResult? = null

    // Tied to the activity: cancelled in onDestroy so work never touches a dead screen.
    private val uiScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    private lateinit var tvSelectedFile: TextView
    private lateinit var tvLog: TextView
    private lateinit var btnProcess: Button
    private lateinit var progressBar: ProgressBar
    private lateinit var etPhrases: EditText
    private lateinit var swBookStyle: CompoundButton

    private val pickEpub = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            selectedUri = uri
            tvSelectedFile.text = queryDisplayName(uri)
            btnProcess.isEnabled = true
        }
    }

    private val createDocument = registerForActivityResult(
        ActivityResultContracts.CreateDocument("application/epub+zip")
    ) { uri ->
        val result = lastResult ?: return@registerForActivityResult
        lastResult = null

        if (uri == null) {
            // The user cancelled the save dialog: just clean up.
            uiScope.launch(Dispatchers.IO) { EpubProcessor.cleanup(result) }
            return@registerForActivityResult
        }

        uiScope.launch {
            val error: String? = try {
                // Repackaging the book can be slow, so keep it off the main thread.
                withContext(Dispatchers.IO) {
                    val out = contentResolver.openOutputStream(uri)
                    if (out == null) {
                        "Could not open the destination file."
                    } else {
                        out.use { EpubProcessor.writeResult(result, it) }
                        null
                    }
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                "Could not save the file: ${e.message}"
            }

            tvLog.append(if (error == null) "\n\n✅ Saved successfully." else "\n\n⚠️ $error")
            withContext(Dispatchers.IO) { EpubProcessor.cleanup(result) }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        tvSelectedFile = findViewById(R.id.tvSelectedFile)
        tvLog = findViewById(R.id.tvLog)
        btnProcess = findViewById(R.id.btnProcess)
        progressBar = findViewById(R.id.progressBar)
        etPhrases = findViewById(R.id.etPhrases)
        etPhrases.setText(loadSavedPhrases())
        
        swBookStyle = findViewById(R.id.swBookStyle)
        swBookStyle.isChecked = false
        
        // Remove work files left behind by earlier sessions (e.g. if the app was killed mid-way).
        uiScope.launch(Dispatchers.IO) { EpubProcessor.cleanupStale(applicationContext) }

        findViewById<Button>(R.id.btnSelect).setOnClickListener {
            pickEpub.launch(arrayOf("application/epub+zip", "*/*"))
        }

        btnProcess.setOnClickListener {
            val uri = selectedUri ?: return@setOnClickListener
            val format = if (findViewById<RadioGroup>(R.id.rgFormat).checkedRadioButtonId == R.id.rbKepub)
                OutputFormat.KEPUB else OutputFormat.EPUB

            val phrases = etPhrases.text.toString()
                .split("\n")
                .map { it.trim() }
                .filter { it.isNotEmpty() }

            savePhrases(etPhrases.text.toString())
            saveBookStyle(swBookStyle.isChecked)
            processFile(uri, format, phrases, swBookStyle.isChecked)
        }
    }

    override fun onDestroy() {
        uiScope.cancel()
        super.onDestroy()
    }

    private fun processFile(uri: Uri, format: OutputFormat, phrases: List<String>, addBookStyle: Boolean) {
        progressBar.visibility = View.VISIBLE
        btnProcess.isEnabled = false
        tvLog.text = "Processing..."

        // A previous result that was never saved is discarded.
        val previous = lastResult
        lastResult = null

        uiScope.launch {
            try {
                val result = withContext(Dispatchers.IO) {
                    previous?.let { EpubProcessor.cleanup(it) }
                    EpubProcessor.process(this@MainActivity, uri, format, phrases, addBookStyle)
                }
                lastResult = result
                tvLog.text = if (result.report.fixes.isEmpty())
                    "No issues were found that needed fixing."
                else
                    result.report.fixes.joinToString("\n") { "• $it" }

                progressBar.visibility = View.GONE
                btnProcess.isEnabled = true
                createDocument.launch(result.suggestedFileName)

            } catch (e: CancellationException) {
                throw e
            } catch (e: EpubStructureException) {
                progressBar.visibility = View.GONE
                btnProcess.isEnabled = true
                tvLog.text = "⚠️ ${e.message}"

            } catch (e: DrmProtectedException) {
                progressBar.visibility = View.GONE
                btnProcess.isEnabled = true
                tvLog.text = "⚠️ ${e.message}"

            } catch (e: Exception) {
                progressBar.visibility = View.GONE
                btnProcess.isEnabled = true
                tvLog.text = "⚠️ Unexpected error: ${e.message}"
            }
        }
    }

    private fun loadBookStyle(): Boolean {
    val prefs = getSharedPreferences("kepubdoctor_prefs", MODE_PRIVATE)
    return prefs.getBoolean("book_style", false)
}

private fun saveBookStyle(enabled: Boolean) {
    val prefs = getSharedPreferences("kepubdoctor_prefs", MODE_PRIVATE)
    prefs.edit().putBoolean("book_style", enabled).apply()
}

    private fun loadSavedPhrases(): String {
        val prefs = getSharedPreferences("kepubdoctor_prefs", MODE_PRIVATE)
        return prefs.getString("custom_phrases", "") ?: ""
    }

    private fun savePhrases(text: String) {
        val prefs = getSharedPreferences("kepubdoctor_prefs", MODE_PRIVATE)
        prefs.edit().putString("custom_phrases", text).apply()
    }

    private fun queryDisplayName(uri: Uri): String {
        var name = uri.lastPathSegment ?: "file.epub"
        contentResolver.query(uri, null, null, null, null)?.use { cursor ->
            val idx = cursor.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
            if (idx != -1 && cursor.moveToFirst()) {
                name = cursor.getString(idx)
            }
        }
        return name
    }
}
