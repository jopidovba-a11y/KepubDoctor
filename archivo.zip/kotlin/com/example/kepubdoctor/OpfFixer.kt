package com.example.kepubdoctor

import org.jsoup.Jsoup
import org.jsoup.parser.Parser
import java.io.File

object OpfFixer {

    fun fixCoverImageProperty(opfFile: File, report: FixReport) {
        if (!opfFile.exists()) return
        val doc = Jsoup.parse(opfFile.readText(), "", Parser.xmlParser())
        var fixed = false

        val coverMetaId = doc.select("meta[name=cover]").firstOrNull()?.attr("content")
        if (!coverMetaId.isNullOrBlank()) {
            val item = doc.select("manifest item[id=\"$coverMetaId\"]").firstOrNull()
            if (item != null && !item.attr("properties").contains("cover-image")) {
                val existing = item.attr("properties").trim()
                item.attr("properties", if (existing.isBlank()) "cover-image" else "$existing cover-image")
                fixed = true
            }
        }

        val coverIdItem = doc.select("manifest item[id=cover]").firstOrNull()
        if (coverIdItem != null && !coverIdItem.attr("properties").contains("cover-image")) {
            val existing = coverIdItem.attr("properties").trim()
            coverIdItem.attr("properties", if (existing.isBlank()) "cover-image" else "$existing cover-image")
            fixed = true
        }

        if (fixed) {
            opfFile.writeText(doc.outerHtml())
            report.fixes.add("cover-image property added to the manifest (Kobo only detects covers this way)")
        }
    }

    // Calibre metadata worth keeping: Kobo uses these two to group books by series in the library.
    private val KEEP_CALIBRE_META = setOf("calibre:series", "calibre:series_index")

    fun removeCalibreMetadata(opfFile: File, report: FixReport) {
        if (!opfFile.exists()) return
        val doc = Jsoup.parse(opfFile.readText(), "", Parser.xmlParser())
        val calibreMetas = doc.select("meta[name^=calibre]").toList()
            .filter { it.attr("name").trim().lowercase() !in KEEP_CALIBRE_META }
        if (calibreMetas.isNotEmpty()) {
            val count = calibreMetas.size
            calibreMetas.forEach { it.remove() }
            opfFile.writeText(doc.outerHtml())
            report.fixes.add("$count unneeded Calibre metadata entr${if (count == 1) "y" else "ies"} removed from the OPF (series info kept)")
        }
    }
}
