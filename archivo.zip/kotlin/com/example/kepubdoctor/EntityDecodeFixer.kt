package com.example.kepubdoctor

import org.jsoup.parser.Parser
import java.io.File

object EntityDecodeFixer {

    // Detects valid HTML entity patterns left as literal text
    // (e.g. &#8230; or &amp; or &hellip;) instead of being decoded to the real character.
    private val ENTITY_PATTERN = Regex("&(#\\d+|#x[0-9a-fA-F]+|[a-zA-Z]+);")

    fun fixAll(epubDir: File, report: FixReport) {
        var fixedCount = 0
        var filesAffected = 0

        epubDir.walkTopDown()
            .filter { it.isFile && (it.extension == "xhtml" || it.extension == "html" || it.extension == "htm") }
            .forEach { file ->
                val original = file.readText()
                val doc = XhtmlUtils.parse(original)
                var fileChanged = false

                doc.allElements.forEach { el ->
                    for (textNode in el.textNodes().toList()) {
                        val text = textNode.text()
                        if (ENTITY_PATTERN.containsMatchIn(text)) {
                            val decoded = Parser.unescapeEntities(text, false)
                            if (decoded != text) {
                                textNode.text(decoded)
                                fixedCount += ENTITY_PATTERN.findAll(text).count()
                                fileChanged = true
                            }
                        }
                    }
                }

                if (fileChanged) {
                    filesAffected++
                    file.writeText(XhtmlUtils.serialize(doc))
                }
            }

        if (fixedCount > 0) {
            report.fixes.add("$fixedCount double-escaped HTML entit${if (fixedCount == 1) "y" else "ies"} decoded to the real character (e.g. &amp;#8230; → …) in $filesAffected file(s)")
        }
    }
}