package com.example.kepubdoctor

import org.jsoup.Jsoup
import org.jsoup.nodes.Document
import org.jsoup.parser.Parser
import java.io.File

object TitlepageFixer {

    const val DUMMY_FILENAME = "kepubdoctor-titlepage.xhtml"
    private const val DUMMY_ID = "kepubdoctor-titlepage"

    fun ensureStandaloneTitlepage(opfFile: File, report: FixReport) {
        if (!opfFile.exists()) return
        val doc = Jsoup.parse(opfFile.readText(), "", Parser.xmlParser())

        // Already added by a previous run: don't insert a second one.
        if (doc.select("manifest item[id=\"$DUMMY_ID\"]").isNotEmpty()) return

        val firstItemref = doc.select("spine itemref").firstOrNull() ?: return
        val firstIdref = firstItemref.attr("idref")
        val manifestItem = doc.select("manifest item[id=\"$firstIdref\"]").firstOrNull() ?: return
        val href = manifestItem.attr("href")
        val opfDir = opfFile.parentFile ?: return
        val firstContentFile = XhtmlUtils.resolveHref(opfDir, href)

        if (!firstContentFile.exists() || !looksLikeStandaloneCover(firstContentFile)) {
            insertDummyTitlepage(opfFile, doc, opfDir, report)
        }
    }

    private fun looksLikeStandaloneCover(file: File): Boolean {
        val html = Jsoup.parse(file.readText())
        val bodyText = html.body()?.text()?.trim() ?: ""
        val hasImage = html.select("img, image").isNotEmpty()
        return hasImage && bodyText.length < 60
    }

    private fun insertDummyTitlepage(opfFile: File, doc: Document, opfDir: File, report: FixReport) {
        val dummyFile = File(opfDir, DUMMY_FILENAME)
        dummyFile.writeText(
            """<?xml version="1.0" encoding="UTF-8"?>
<html xmlns="http://www.w3.org/1999/xhtml">
<head><title></title></head>
<body></body>
</html>"""
        )

        val manifest = doc.select("manifest").firstOrNull() ?: return
        val newItem = doc.createElement("item")
        newItem.attr("id", DUMMY_ID)
        newItem.attr("href", DUMMY_FILENAME)
        newItem.attr("media-type", "application/xhtml+xml")
        manifest.prependChild(newItem)

        val spine = doc.select("spine").firstOrNull() ?: return
        val newItemref = doc.createElement("itemref")
        newItemref.attr("idref", DUMMY_ID)
        spine.prependChild(newItemref)

        opfFile.writeText(doc.outerHtml())
        report.fixes.add("Standalone cover page added at the start (fixes margins/full-screen wrongly applied by Kobo to the first chapter)")
    }
}
