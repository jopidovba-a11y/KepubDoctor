package com.example.kepubdoctor

import org.jsoup.Jsoup
import org.jsoup.parser.Parser
import java.io.File
import java.net.URLEncoder

/**
 * Makes books follow the reader's own settings:
 *  1. Removes fixed font sizes / line heights / font families from html, body and p rules.
 *  2. Adds a minimal stylesheet to books that have no styling at all (typical for web novels).
 */
object ReaderStyleFixer {

    const val DEFAULT_CSS_FILENAME = "kepubdoctor-style.css"
    private const val DEFAULT_CSS_ID = "kepubdoctor-style"

    // Written in the compact form ParagraphSpacingFixer produces, so reprocessing a book never rewrites it.
    private val DEFAULT_CSS = """p{margin-top: 0; margin-bottom: 0; text-indent: 1.2em; text-align: justify}
h1 + p, h2 + p, h3 + p, h4 + p, hr + p{text-indent: 0}
"""

    // Only these selectors are touched: html, body, p and p.someclass
    private val TARGET_SELECTOR = Regex("^(html|body|p(\\.[\\w-]+)?)$", RegexOption.IGNORE_CASE)
    // Absolute units do not scale with the reader's font size setting (em, %, rem and unitless values do).
    private val ABSOLUTE_VALUE = Regex("^\\d*\\.?\\d+(px|pt|pc|cm|mm|in)(\\s*!important)?$", RegexOption.IGNORE_CASE)
    private val RULE_BLOCK = Regex("""([^{}]+)\{([^{}]*)\}""")
    private val FONT_FACE_BLOCK = Regex("""@font-face\s*\{([^{}]*)\}""", RegexOption.IGNORE_CASE)
    private val FAMILY_DECL = Regex("""font-family\s*:\s*([^;}]+)""", RegexOption.IGNORE_CASE)

    fun fixAll(epubDir: File, opfFile: File?, report: FixReport, addBookStyle: Boolean = false) {
    makeStylesFollowReaderSettings(epubDir, report)
    // The book-style stylesheet (first-line indent, no gaps) is optional and off by default.
    if (opfFile != null && addBookStyle) addDefaultStylesheetIfMissing(opfFile, report)
    }

    // ---------------------------------------------------------------- 1. existing stylesheets

    private fun makeStylesFollowReaderSettings(epubDir: File, report: FixReport) {
        val cssFiles = epubDir.walkTopDown()
            .filter { it.isFile && it.extension.equals("css", ignoreCase = true) }
            .toList()
        if (cssFiles.isEmpty()) return

        // Fonts embedded by the book on purpose are left alone.
        val embeddedFamilies = HashSet<String>()
        cssFiles.forEach { file ->
            FONT_FACE_BLOCK.findAll(file.readText()).forEach { block ->
                FAMILY_DECL.find(block.groupValues[1])?.let { m ->
                    embeddedFamilies.addAll(splitFamilies(m.groupValues[1]))
                }
            }
        }

        var filesFixed = 0
        cssFiles.forEach { file ->
            val original = file.readText()
            val cleaned = cleanRules(original, embeddedFamilies)
            if (cleaned != original) {
                file.writeText(cleaned)
                filesFixed++
            }
        }
        if (filesFixed > 0) {
            report.fixes.add("$filesFixed CSS stylesheet(s): fixed font size/line height/font family removed from body and paragraphs so your reader's settings apply")
        }
    }

    private fun splitFamilies(value: String): List<String> =
        value.split(",").map { it.trim().trim('"', '\'').lowercase() }.filter { it.isNotEmpty() }

    fun cleanRules(css: String, embeddedFamilies: Set<String>): String {
        return RULE_BLOCK.replace(css) { match ->
            val selectorPart = match.groupValues[1]
            val declarations = match.groupValues[2]

            // Ignore anything before the rule itself (e.g. "@import ...;" or "@charset ...;")
            val selectorText = selectorPart.substringAfterLast(';').trim()
            val pieces = selectorText.split(",").map { it.trim() }
            if (pieces.isEmpty() || !pieces.all { TARGET_SELECTOR.matches(it) }) return@replace match.value

            var removed = 0
            val kept = declarations.split(";").filter { decl ->
                val t = decl.trim()
                if (t.isEmpty()) return@filter true
                val name = t.substringBefore(":").trim().lowercase()
                val value = t.substringAfter(":", "").trim()
                val drop = when (name) {
                    "font-size", "line-height" -> ABSOLUTE_VALUE.matches(value)
                    "font-family" -> splitFamilies(value).none { it in embeddedFamilies }
                    else -> false
                }
                if (drop) removed++
                !drop
            }
            if (removed == 0) match.value else "$selectorPart{${kept.joinToString(";")}}"
        }
    }

    // ---------------------------------------------------------------- 2. books with no styling

    private fun addDefaultStylesheetIfMissing(opfFile: File, report: FixReport) {
        if (!opfFile.exists()) return
        val doc = Jsoup.parse(opfFile.readText(), "", Parser.xmlParser())
        val opfDir = opfFile.parentFile ?: return

        val manifestItems = doc.select("manifest item").toList()
        val hasCss = manifestItems.any {
            it.attr("media-type").equals("text/css", ignoreCase = true) ||
                it.attr("href").endsWith(".css", ignoreCase = true)
        }
        if (hasCss) return

        val contentFiles = doc.select("spine itemref").toList().mapNotNull { ref ->
            val item = doc.select("manifest item[id=\"${ref.attr("idref")}\"]").firstOrNull() ?: return@mapNotNull null
            val href = item.attr("href")
            val isDocument = item.attr("media-type").equals("application/xhtml+xml", ignoreCase = true)
            val isNav = item.attr("properties").split(" ").contains("nav")
            if (!isDocument || isNav || File(href).name == TitlepageFixer.DUMMY_FILENAME) return@mapNotNull null
            XhtmlUtils.resolveHref(opfDir, href).takeIf { it.exists() }
        }
        if (contentFiles.isEmpty()) return

        // Inline <style> blocks or stylesheet links mean the book does have its own styling.
        val hasOwnStyling = contentFiles.any {
            val text = it.readText().lowercase()
            text.contains("<style") || text.contains("stylesheet")
        }
        if (hasOwnStyling) return

        File(opfDir, DEFAULT_CSS_FILENAME).writeText(DEFAULT_CSS)

        val manifest = doc.select("manifest").firstOrNull() ?: return
        val newItem = doc.createElement("item")
        newItem.attr("id", DEFAULT_CSS_ID)
        newItem.attr("href", DEFAULT_CSS_FILENAME)
        newItem.attr("media-type", "text/css")
        manifest.appendChild(newItem)
        opfFile.writeText(doc.outerHtml())

        val cssFile = File(opfDir, DEFAULT_CSS_FILENAME)
        contentFiles.forEach { file ->
            val html = XhtmlUtils.parse(file.readText())
            val relative = cssFile.relativeTo(file.parentFile ?: opfDir).path
                .split(File.separatorChar)
                .joinToString("/") { segment -> URLEncoder.encode(segment, "UTF-8").replace("+", "%20") }
            html.head().appendElement("link")
                .attr("rel", "stylesheet")
                .attr("type", "text/css")
                .attr("href", relative)
            file.writeText(XhtmlUtils.serialize(html))
        }

        report.fixes.add("Basic stylesheet added to ${contentFiles.size} chapter(s) (first-line indent, no gaps between paragraphs, justified text) because the book had no styling")
    }
}
