package com.example.kepubdoctor

import org.jsoup.Jsoup
import org.jsoup.nodes.Element
import org.jsoup.nodes.Entities
import org.jsoup.nodes.TextNode
import java.io.File

object StrayTagFixer {

    private val KNOWN_TAG_NAMES = listOf(
        "span", "div", "p", "a", "b", "i", "u", "em", "strong", "font",
        "br", "hr", "img", "sup", "sub", "small", "mark", "s", "strike"
    ).joinToString("|")

    private val STRAY_TAG_PATTERN = Regex(
    "</?(?:$KNOWN_TAG_NAMES)(?:\\s+[^<>]{0,80})?\\s*/?>",
    RegexOption.IGNORE_CASE
)

    private val VOID_TAGS = setOf("br", "hr", "img")
    private val BLOCK_TAGS = listOf("p", "div", "li", "blockquote", "td", "h1", "h2", "h3", "h4", "h5", "h6")

    fun fixAll(epubDir: File, report: FixReport) {
        var blocksPromoted = 0
        var filesAffected = 0

        epubDir.walkTopDown()
            .filter { it.isFile && (it.extension == "xhtml" || it.extension == "html" || it.extension == "htm") }
            .forEach { file ->
                val original = file.readText()
                val doc = XhtmlUtils.parse(original)
                var fileChanged = false

                for (blockTag in BLOCK_TAGS) {
                    for (block in doc.select(blockTag)) {
                        if (!containsStrayText(block)) continue

                        val rebuiltHtml = rebuildInnerHtml(block)
                        val fragment = Jsoup.parseBodyFragment(rebuiltHtml).body()

                        block.empty()
                        for (node in fragment.childNodes().toList()) {
                            node.remove()
                            block.appendChild(node)
                        }

                        // Safety net: if anything is still unpaired for some reason, strip it as plain text
                        stripRemainingStrayText(block)

                        blocksPromoted++
                        fileChanged = true
                    }
                }

                if (fileChanged) {
                    filesAffected++
                    file.writeText(XhtmlUtils.serialize(doc))
                }
            }

        if (blocksPromoted > 0) {
            report.fixes.add("$blocksPromoted block(s) with stray HTML tags recovered as real formatting (e.g. underline/bold) in $filesAffected file(s)")
        }
    }

    private fun containsStrayText(el: Element): Boolean {
        return el.textNodes().any { STRAY_TAG_PATTERN.containsMatchIn(it.text()) } ||
            el.children().any { containsStrayText(it) }
    }

    /** Rebuilds the inner HTML of a block, leaving any fragment that looks like a stray tag
     *  "raw" (unescaped) so that re-parsing turns it into a real tag. The rest of the text is
     *  escaped normally so nothing else breaks. */
    private fun rebuildInnerHtml(node: Element): String {
        val sb = StringBuilder()
        for (child in node.childNodes()) {
            when (child) {
                is TextNode -> sb.append(promoteText(child.text()))
                is Element -> {
                    val innerPromoted = rebuildInnerHtml(child)
                    val attrs = child.attributes().joinToString(" ") { "${it.key}=\"${escapeAttr(it.value)}\"" }
                    val attrsPart = if (attrs.isNotBlank()) " $attrs" else ""
                    if (child.tagName().lowercase() in VOID_TAGS) {
                        sb.append("<${child.tagName()}$attrsPart/>")
                    } else {
                        sb.append("<${child.tagName()}$attrsPart>").append(innerPromoted).append("</${child.tagName()}>")
                    }
                }
                else -> { /* comments, etc.: skipped, irrelevant here */ }
            }
        }
        return sb.toString()
    }

    private fun promoteText(text: String): String {
        val sb = StringBuilder()
        var lastEnd = 0
        for (match in STRAY_TAG_PATTERN.findAll(text)) {
            sb.append(Entities.escape(text.substring(lastEnd, match.range.first)))
            sb.append(match.value) // left as-is so it gets parsed as a real tag
            lastEnd = match.range.last + 1
        }
        sb.append(Entities.escape(text.substring(lastEnd)))
        return sb.toString()
    }

    /** Safety net: if an unpaired fragment remains after rebuilding (e.g. an orphan closing tag
     *  with no opening tag in the same block), it is removed as text instead of being left visible. */
    private fun stripRemainingStrayText(el: Element) {
        for (textNode in el.textNodes().toList()) {
            val text = textNode.text()
            if (STRAY_TAG_PATTERN.containsMatchIn(text)) {
                textNode.text(STRAY_TAG_PATTERN.replace(text, ""))
            }
        }
        el.children().forEach { stripRemainingStrayText(it) }
    }

    private fun escapeAttr(value: String): String =
        value.replace("&", "&amp;").replace("\"", "&quot;").replace("<", "&lt;")
}
