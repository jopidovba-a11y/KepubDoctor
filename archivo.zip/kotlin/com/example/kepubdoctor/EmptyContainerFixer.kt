package com.example.kepubdoctor

import org.jsoup.nodes.Element
import java.io.File

object EmptyContainerFixer {

    private val INVISIBLE_WHITESPACE = Regex("[\\s\\u00A0\\u200B\\u2007\\u202F\\uFEFF]")
    private val VISUAL_CONTENT_SELECTOR = "img, svg, image, video, audio, iframe, canvas"

    // Empty containers with these class names are usually CSS-drawn scene separators; keep them.
    private val SEPARATOR_CLASS = Regex("(scene|break|separator|divider|ornament|flourish|dinkus|asterism)", RegexOption.IGNORE_CASE)

    fun fixAll(epubDir: File, report: FixReport) {
        var totalRemoved = 0
        // Anchors that links point to (footnotes, page breaks, TOC targets) must survive even if empty.
        val referencedIds = XhtmlUtils.collectReferencedIds(epubDir)

        epubDir.walkTopDown()
            .filter { it.isFile && (it.extension == "xhtml" || it.extension == "html" || it.extension == "htm") }
            .forEach { file ->
                val original = file.readText()
                val doc = XhtmlUtils.parse(original)

                val removed = removeEmptyContainers(doc, referencedIds)
                totalRemoved += removed

                if (removed > 0) {
                    file.writeText(XhtmlUtils.serialize(doc))
                }
            }

        if (totalRemoved > 0) {
            report.fixes.add("$totalRemoved empty container(s) removed (leftovers from ads/widgets with no real content that left blank gaps)")
        }
    }

    private fun removeEmptyContainers(doc: org.jsoup.nodes.Document, referencedIds: Set<String>): Int {
        var count = 0
        var changed = true

        while (changed) {
            changed = false
            val candidates = doc.select("div, span").toList()
                .filter { it.tagName().lowercase() != "body" }
                .sortedByDescending { it.parents().size }

            for (el in candidates) {
                if (el.parent() == null) continue
                if (el.hasClass("koboSpan")) continue
                if (isEmptyVisual(el) && !isProtected(el, referencedIds)) {
                    el.remove()
                    count++
                    changed = true
                }
            }
        }
        return count
    }

    private fun isProtected(el: Element, referencedIds: Set<String>): Boolean {
        if (SEPARATOR_CLASS.containsMatchIn(el.className())) return true
        return XhtmlUtils.containsReferencedId(el, referencedIds)
    }

    private fun isEmptyVisual(el: Element): Boolean {
        val text = el.text().replace(INVISIBLE_WHITESPACE, "")
        if (text.isNotEmpty()) return false
        if (el.select(VISUAL_CONTENT_SELECTOR).isNotEmpty()) return false
        return true
    }
}
