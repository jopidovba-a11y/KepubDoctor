package com.example.kepubdoctor

import org.jsoup.Jsoup
import org.jsoup.parser.Parser
import java.io.File
import java.nio.charset.Charset

data class FixReport(val fixes: MutableList<String> = mutableListOf())

object EpubFixer {

    fun fixAll(epubDir: File, customPhrases: List<String> = emptyList(), addBookStyle: Boolean = false): FixReport {
        val report = FixReport()

        fixMimetype(epubDir, report)
        val opfPath = ensureContainerXml(epubDir, report)
        val opfFile: File? = opfPath?.let { File(epubDir, it) }
        if (opfFile != null) {
            fixOpf(opfFile, report)
            OpfFixer.fixCoverImageProperty(opfFile, report)
            OpfFixer.removeCalibreMetadata(opfFile, report)
            ManifestFixer.fixAll(opfFile, report)
            TitlepageFixer.ensureStandaloneTitlepage(opfFile, report)
            NavNcxFixer.fixAll(opfFile, report)
        }
        fixAllXhtml(epubDir, report)
        EntityDecodeFixer.fixAll(epubDir, report)
        CssFixer.fixAll(epubDir, report)
        PhraseRemover.fixAll(epubDir, customPhrases, report)
        EmptyContainerFixer.fixAll(epubDir, report)
        ParagraphSpacingFixer.fixAll(epubDir, report)
        StrayTagFixer.fixAll(epubDir, report)
        ItalicSpaceFixer.fixAll(epubDir, report)
        ContentCleanup.fixAll(epubDir, report)

        // Reader-friendly styling, then drop whatever the book no longer references.
        ReaderStyleFixer.fixAll(epubDir, opfFile, report, addBookStyle)
        if (opfFile != null) UnusedResourceRemover.fixAll(epubDir, opfFile, report)

        return report
    }

    private fun fixMimetype(epubDir: File, report: FixReport) {
        val mime = File(epubDir, "mimetype")
        val correct = "application/epub+zip"
        if (!mime.exists() || mime.readText().trim() != correct) {
            mime.writeText(correct)
            report.fixes.add("mimetype fixed or created")
        }
    }

    private fun ensureContainerXml(epubDir: File, report: FixReport): String? {
        val containerFile = epubDir.walkTopDown().firstOrNull {
            it.isFile && it.name.equals("container.xml", ignoreCase = true) &&
            it.parentFile?.name.equals("META-INF", ignoreCase = true)
        }

        if (containerFile != null) {
            val epubRoot = containerFile.parentFile?.parentFile ?: epubDir
            val doc = Jsoup.parse(containerFile.readText(), "", Parser.xmlParser())
            val rawPath = doc.select("rootfile").firstOrNull()?.attr("full-path")
            val normalizedPath = rawPath
                ?.replace('\\', '/')
                ?.trim()
                ?.removePrefix("./")
                ?.removePrefix("/")

            if (!normalizedPath.isNullOrBlank()) {
                val candidate = File(epubRoot, normalizedPath)
                if (candidate.exists()) {
                    return candidate.relativeTo(epubDir).path.replace(File.separatorChar, '/')
                }
                val match = epubRoot.walkTopDown().firstOrNull {
                    it.isFile && it.relativeTo(epubRoot).path.replace(File.separatorChar, '/')
                        .equals(normalizedPath, ignoreCase = true)
                }
                if (match != null) return match.relativeTo(epubDir).path.replace(File.separatorChar, '/')
            }
            report.fixes.add("container.xml exists but points to an invalid OPF, rebuilding...")
        }

        val opfFile = epubDir.walkTopDown()
            .firstOrNull { it.isFile && it.extension.equals("opf", ignoreCase = true) }

        if (opfFile == null) {
            report.fixes.add("ERROR: no .opf file found; cannot rebuild container.xml")
            return null
        }

        val relativePath = opfFile.relativeTo(epubDir).path.replace(File.separatorChar, '/')
        val containerOut = File(epubDir, "META-INF/container.xml")
        containerOut.parentFile?.mkdirs()
        containerOut.writeText(
            """<?xml version="1.0" encoding="UTF-8"?>
<container version="1.0" xmlns="urn:oasis:names:tc:opendocument:xmlns:container">
  <rootfiles>
    <rootfile full-path="$relativePath" media-type="application/oebps-package+xml"/>
  </rootfiles>
</container>"""
        )
        report.fixes.add("META-INF/container.xml rebuilt (points to $relativePath)")
        return relativePath
    }

    private fun fixOpf(opfFile: File, report: FixReport) {
        if (!opfFile.exists()) {
            report.fixes.add("WARNING: the referenced OPF does not exist")
            return
        }
        val doc = Jsoup.parse(opfFile.readText(), "", Parser.xmlParser())

        val langEl = doc.select("dc|language, language").firstOrNull()
        if (langEl != null) {
            val normalized = normalizeLangCode(langEl.text())
            if (normalized != langEl.text()) {
                langEl.text(normalized)
                report.fixes.add("Language code normalized to '$normalized'")
            }
        }

        val idEl = doc.select("dc|identifier, identifier").firstOrNull()
        if (idEl == null) {
            report.fixes.add("WARNING: dc:identifier is missing from the OPF")
        }

        opfFile.writeText(doc.outerHtml())
    }

    private fun normalizeLangCode(code: String): String {
        val map = mapOf(
            "spa" to "es", "eng" to "en", "fre" to "fr", "fra" to "fr",
            "ger" to "de", "deu" to "de", "ita" to "it", "por" to "pt"
        )
        val trimmed = code.trim().lowercase()
        return map[trimmed] ?: trimmed
    }

    private fun fixAllXhtml(epubDir: File, report: FixReport) {
        var repaired = 0
        var reencoded = 0
        epubDir.walkTopDown()
            .filter { it.isFile && (it.extension == "xhtml" || it.extension == "html" || it.extension == "htm") }
            .forEach { file ->
                val rawBytes = file.readBytes()
                val detected = detectCharset(rawBytes)
                if (detected != Charsets.UTF_8) reencoded++

                val originalText = decodeStrippingBom(rawBytes, detected)
                val cleaned = repairXhtml(originalText)

                if (cleaned != originalText || detected != Charsets.UTF_8) {
                    file.writeBytes(cleaned.toByteArray(Charsets.UTF_8))
                    repaired++
                }
            }
        if (reencoded > 0) report.fixes.add("$reencoded file(s) re-encoded to UTF-8 (a different encoding was detected)")
        if (repaired > 0) report.fixes.add("$repaired XHTML file(s) repaired/normalized")
    }

    private fun detectCharset(bytes: ByteArray): Charset {
        if (bytes.size >= 3 && bytes[0] == 0xEF.toByte() && bytes[1] == 0xBB.toByte() && bytes[2] == 0xBF.toByte()) {
            return Charsets.UTF_8
        }
        if (bytes.size >= 2 && bytes[0] == 0xFF.toByte() && bytes[1] == 0xFE.toByte()) {
            return Charsets.UTF_16LE
        }
        if (bytes.size >= 2 && bytes[0] == 0xFE.toByte() && bytes[1] == 0xFF.toByte()) {
            return Charsets.UTF_16BE
        }

        val sampleSize = minOf(bytes.size, 400)
        if (sampleSize < 4) return Charsets.UTF_8

        var nullCount = 0
        var evenNulls = 0
        var oddNulls = 0
        for (i in 0 until sampleSize) {
            if (bytes[i] == 0.toByte()) {
                nullCount++
                if (i % 2 == 0) evenNulls++ else oddNulls++
            }
        }
        if (nullCount > sampleSize / 4) {
            return if (oddNulls > evenNulls) Charsets.UTF_16LE else Charsets.UTF_16BE
        }
        return Charsets.UTF_8
    }

    private fun decodeStrippingBom(bytes: ByteArray, charset: Charset): String {
        val text = String(bytes, charset)
        return text.removePrefix("\uFEFF")
    }

    fun repairXhtml(content: String): String {
        val doc = XhtmlUtils.parse(content)
        return XhtmlUtils.serialize(doc)
    }
}