package com.example.kepubdoctor

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.ExifInterface
import java.io.File

/**
 * Shrinks JPEG/PNG images wider than an e-reader screen. Images that already fit are never touched,
 * and a resized copy only replaces the original when it is actually smaller.
 */
object ImageOptimizer {

    private const val MAX_WIDTH = 1448   // long side of a Kobo Clara BW screen (1072x1448)
    private const val JPEG_QUALITY = 85

    fun optimize(epubDir: File, report: FixReport) {
        var resized = 0
        var savedBytes = 0L

        epubDir.walkTopDown()
            .filter { it.isFile && it.extension.lowercase() in setOf("jpg", "jpeg", "png") }
            .toList()
            .forEach { file ->
                try {
                    val saved = optimizeFile(file)
                    if (saved > 0) {
                        resized++
                        savedBytes += saved
                    }
                } catch (e: Throwable) {
                    // Any failure (including out of memory): the original image stays as it was.
                }
            }

        if (resized > 0) {
            report.fixes.add("$resized image(s) wider than $MAX_WIDTH px resized for e-reader screens (saved ${savedBytes / 1024} KB)")
        }
    }

    /** Returns the number of bytes saved, or 0 if the file was left untouched. */
    private fun optimizeFile(file: File): Long {
        val isJpeg = file.extension.lowercase() != "png"

        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(file.path, bounds)
        val width = bounds.outWidth
        val height = bounds.outHeight
        if (width <= MAX_WIDTH || height <= 0) return 0

        // Recompressing a JPEG drops its EXIF data, so leave rotated photos alone.
        if (isJpeg && hasRotation(file)) return 0

        // Decode at a reduced size first (powers of two) so huge images never need a full-size bitmap.
        var sample = 1
        while (width / (sample * 2) >= MAX_WIDTH) sample *= 2

        val decoded = BitmapFactory.decodeFile(file.path, BitmapFactory.Options().apply { inSampleSize = sample })
            ?: return 0

        val targetHeight = maxOf(1, (height.toLong() * MAX_WIDTH / width).toInt())
        val scaled = if (decoded.width == MAX_WIDTH) decoded
        else Bitmap.createScaledBitmap(decoded, MAX_WIDTH, targetHeight, true)
        if (scaled !== decoded) decoded.recycle()

        val temp = File(file.parentFile, file.name + ".kdtmp")
        try {
            temp.outputStream().use { out ->
                if (isJpeg) scaled.compress(Bitmap.CompressFormat.JPEG, JPEG_QUALITY, out)
                else scaled.compress(Bitmap.CompressFormat.PNG, 100, out)
            }
            scaled.recycle()

            val before = file.length()
            val after = temp.length()
            if (after in 1 until before) {
                temp.copyTo(file, overwrite = true)
                return before - after
            }
            return 0
        } finally {
            temp.delete()
        }
    }

    private fun hasRotation(file: File): Boolean {
        return try {
            val orientation = ExifInterface(file.path)
                .getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
            orientation != ExifInterface.ORIENTATION_NORMAL && orientation != ExifInterface.ORIENTATION_UNDEFINED
        } catch (e: Exception) {
            true
        }
    }
}
