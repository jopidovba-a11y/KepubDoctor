package com.example.kepubdoctor

import org.jsoup.nodes.Document
import org.jsoup.nodes.Element
import org.jsoup.nodes.TextNode
import java.io.File

object ParagraphSpacingFixer {

    fun fixAll(epubDir: File, report: FixReport) {
        var brCollapsed = 0
        var emptyParasRemoved = 0
        var inlineStylesFixed = 0
        var cssNormalized = 0
        // Anchors that links point to must survive even if their paragraph is empty.
        val referencedIds = XhtmlUtils.collectReferencedIds(epubDir)

        epubDir.walkTopDown()
            .filter { it.isFile && (it.extension == "xhtml" || it.extension == "html" || it.extension == "htm") }
            .forEach { file ->
                val original = file.readText()
                val doc = XhtmlUtils.parse(original)

                brCollapsed += collapseDoubleBreaks(doc)
                emptyParasRemoved += removeSpacerParagraphs(doc, referencedIds)
                inlineStylesFixed += normalizeInlineParagraphStyles(doc)

                val result = XhtmlUtils.serialize(doc)
                if (result != original) file.writeText(result)
            }

        epubDir.walkTopDown()
            .filter { it.isFile && it.extension.equals("css", ignoreCase = true) }
            .forEach { file ->
                val original = file.readText()
                val cleaned = normalizeParagraphMargins(original)
                if (cleaned != original) {
                    file.writeText(cleaned)
                    cssNormalized++
                }
            }

        if (brCollapsed > 0) report.fixes.add("$brCollapsed double/triple line break(s) collapsed into one")
        if (emptyParasRemoved > 0) report.fixes.add("$emptyParasRemoved empty 'spacer' paragraph(s) removed")
        if (inlineStylesFixed > 0) report.fixes.add("$inlineStylesFixed paragraph(s) with inline margin (style=\"\") normalized")
        if (cssNormalized > 0) report.fixes.add("$cssNormalized CSS stylesheet(s) with paragraph margins normalized")
    }

    private fun collapseDoubleBreaks(doc: Document): Int {
        var count = 0
        var changed = true
        while (changed) {
            changed = false
            for (br in doc.select("br")) {
                var next = br.nextSibling()
                while (next != null && next is TextNode && next.text().isBlank()) {
                    next = next.nextSibling()
                }
                if (next is Element && next.tagName().equals("br", ignoreCase = true)) {
                    next.remove()
                    count++
                    changed = true
                    break
                }
            }
        }
        return count
    }

    private fun removeSpacerParagraphs(doc: Document, referencedIds: Set<String>): Int {
        val invisibleWhitespace = Regex("[\\s\\u00A0\\u200B\\u2007\\u202F\\uFEFF]")
        val spacers = doc.select("p").filter { p ->
            val normalizedText = p.text().replace(invisibleWhitespace, "")
            val hasVisualContent = p.select("img, svg, image, hr").isNotEmpty()
            normalizedText.isEmpty() && !hasVisualContent && !XhtmlUtils.containsReferencedId(p, referencedIds)
        }
        spacers.forEach { it.remove() }
        return spacers.size
    }

    private fun normalizeInlineParagraphStyles(doc: Document): Int {
        var fixed = 0
        for (p in doc.select("p")) {
            if (!p.hasAttr("style")) continue
            val original = p.attr("style")
            val normalized = normalizeMarginDeclarations(original)
            if (normalized != original) {
                if (normalized.isBlank()) p.removeAttr("style") else p.attr("style", normalized)
                fixed++
            }
        }
        return fixed
    }

    private fun normalizeMarginDeclarations(declBlock: String): String {
        val declMap = LinkedHashMap<String, String>()
        declBlock.split(";")
            .map { it.trim() }
            .filter { it.isNotEmpty() }
            .forEach { d ->
                val parts = d.split(":", limit = 2)
                val key = parts.getOrNull(0)?.trim()?.lowercase() ?: return@forEach
                val value = parts.getOrNull(1)?.trim() ?: return@forEach
                declMap[key] = value
            }

        fun isNonZero(v: String?) = v != null && v != "0" && !v.startsWith("0px") && !v.startsWith("0em") && !v.startsWith("0pt") && !v.startsWith("0%")

        declMap["margin"]?.let { shorthand ->
            val parts = shorthand.split(Regex("\\s+")).filter { it.isNotBlank() }
            if (parts.size !in 1..4) return@let // unusual value: leave the shorthand untouched

            val top = parts[0]
            val right = parts.getOrElse(1) { top }
            val bottom = parts.getOrElse(2) { top }
            val left = parts.getOrElse(3) { right }

            declMap["margin-top"] = top
            declMap["margin-bottom"] = bottom
            // Keep non-zero horizontal margins carried by the shorthand (they used to be dropped).
            if (isNonZero(left) && !declMap.containsKey("margin-left")) declMap["margin-left"] = left
            if (isNonZero(right) && !declMap.containsKey("margin-right")) declMap["margin-right"] = right
            declMap.remove("margin")
        }

        if (isNonZero(declMap["margin-top"]) && isNonZero(declMap["margin-bottom"])) {
            declMap["margin-top"] = "0"
        }

        return declMap.entries.joinToString("; ") { (k, v) -> "$k: $v" }
    }

    fun normalizeParagraphMargins(css: String): String {
        val noComments = css.replace(Regex("/\\*.*?\\*/", RegexOption.DOT_MATCHES_ALL), "")
        val blockRegex = Regex("""(?<![\w.#-])(p(?:\.[\w-]+)?)\s*\{([^{}]*)\}""")

        return blockRegex.replace(noComments) { match ->
            val selector = match.groupValues[1]
            val decls = match.groupValues[2]
            val normalized = normalizeMarginDeclarations(decls.replace(";", "; "))
            "$selector{$normalized}"
        }
    }
}