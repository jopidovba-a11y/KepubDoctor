package com.example.kepubdoctor

import java.io.File
import java.util.zip.CRC32
import java.util.zip.ZipEntry
import java.util.zip.ZipFile
import java.util.zip.ZipOutputStream

object ZipUtils {

    private val JUNK_PATTERNS = listOf(
        "calibre_bookmarks.txt", "__MACOSX", ".DS_Store", "Thumbs.db", "desktop.ini", "iTunesMetadata.plist"
    )

    fun isJunkFile(relativePath: String): Boolean =
        JUNK_PATTERNS.any { relativePath.contains(it, ignoreCase = true) }

    fun extract(inputStream: java.io.InputStream, targetDir: File, tempZipFile: File): List<String> {
        tempZipFile.parentFile?.mkdirs()
        tempZipFile.outputStream().use { out -> inputStream.copyTo(out) }

        val entryNames = mutableListOf<String>()
        ZipFile(tempZipFile).use { zipFile ->
            val entries = zipFile.entries()
            while (entries.hasMoreElements()) {
                val entry = entries.nextElement()
                val normalizedName = entry.name.replace('\\', '/')
                entryNames.add(normalizedName)

                val outFile = File(targetDir, normalizedName)
                if (entry.isDirectory || normalizedName.endsWith("/")) {
                    outFile.mkdirs()
                } else {
                    outFile.parentFile?.mkdirs()
                    zipFile.getInputStream(entry).use { input ->
                        outFile.outputStream().use { output -> input.copyTo(output) }
                    }
                }
            }
        }
        return entryNames
    }

    fun repackage(sourceDir: File, outputStream: java.io.OutputStream, orderedEntries: List<String>) {
        ZipOutputStream(outputStream).use { zos ->
            val mimetypeFile = File(sourceDir, "mimetype")
            if (mimetypeFile.exists()) {
                val bytes = mimetypeFile.readBytes()
                val entry = ZipEntry("mimetype")
                entry.method = ZipEntry.STORED
                entry.size = bytes.size.toLong()
                entry.compressedSize = bytes.size.toLong()
                val crc = CRC32()
                crc.update(bytes)
                entry.crc = crc.value
                zos.putNextEntry(entry)
                zos.write(bytes)
                zos.closeEntry()
            }

            val allFiles = mutableListOf<String>()
            allFiles.addAll(orderedEntries.filter { it != "mimetype" && !isJunkFile(it) })

            sourceDir.walkTopDown().filter { it.isFile }.forEach { f ->
                val rel = f.relativeTo(sourceDir).path.replace(File.separatorChar, '/')
                if (rel != "mimetype" && rel !in allFiles && !isJunkFile(rel)) {
                    allFiles.add(rel)
                }
            }

            for (rel in allFiles) {
                val f = File(sourceDir, rel)
                if (!f.exists() || !f.isFile) continue
                zos.putNextEntry(ZipEntry(rel))
                f.inputStream().use { it.copyTo(zos) }
                zos.closeEntry()
            }
        }
    }
}