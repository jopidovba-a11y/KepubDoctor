package com.example.kepubdoctor

import org.jsoup.Jsoup
import org.jsoup.nodes.Comment
import org.jsoup.nodes.Document
import org.jsoup.nodes.Entities

object XhtmlUtils {

    private val LEADING_XML_DECL = Regex("""^\uFEFF?\s*<\?xml[^>]*\?>\s*""")

    fun parse(rawContent: String): Document {
        val withoutDecl = rawContent.replace(LEADING_XML_DECL, "")
        val doc = Jsoup.parse(withoutDecl)
        removeBogusXmlDeclarationComments(doc)
        return doc
    }

    private fun removeBogusXmlDeclarationComments(doc: Document) {
        doc.childNodes().filterIsInstance<Comment>()
            .filter { it.data.trim().startsWith("?xml") }
            .forEach { it.remove() }
        doc.select("html, head").forEach { el ->
            el.childNodes().filterIsInstance<Comment>()
                .filter { it.data.trim().startsWith("?xml") }
                .forEach { it.remove() }
        }
    }

    fun serialize(doc: Document): String {
        doc.outputSettings()
            .syntax(Document.OutputSettings.Syntax.xml)
            .escapeMode(Entities.EscapeMode.xhtml)
            .charset(Charsets.UTF_8)
        return "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n" + doc.html()
    }
}