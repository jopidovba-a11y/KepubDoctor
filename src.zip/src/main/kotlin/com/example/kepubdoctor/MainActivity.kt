package com.example.kepubdoctor

import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.ProgressBar
import android.widget.RadioGroup
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : AppCompatActivity() {

    private var selectedUri: Uri? = null
    private var lastResult: ProcessResult? = null

    private lateinit var tvSelectedFile: TextView
    private lateinit var tvLog: TextView
    private lateinit var btnProcess: Button
    private lateinit var progressBar: ProgressBar

    private val pickEpub = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            selectedUri = uri
            tvSelectedFile.text = queryDisplayName(uri)
            btnProcess.isEnabled = true
        }
    }

    private val createDocument = registerForActivityResult(
        ActivityResultContracts.CreateDocument("application/epub+zip")
    ) { uri ->
        val result = lastResult ?: return@registerForActivityResult
        if (uri != null) {
            contentResolver.openOutputStream(uri)?.use { out ->
                EpubProcessor.writeResult(result, out)
            }
            tvLog.append("\n\n✅ Guardado correctamente.")
        }
        EpubProcessor.cleanup(result)
        lastResult = null
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        tvSelectedFile = findViewById(R.id.tvSelectedFile)
        tvLog = findViewById(R.id.tvLog)
        btnProcess = findViewById(R.id.btnProcess)
        progressBar = findViewById(R.id.progressBar)

        findViewById<Button>(R.id.btnSelect).setOnClickListener {
            pickEpub.launch(arrayOf("application/epub+zip", "*/*"))
        }

        btnProcess.setOnClickListener {
            val uri = selectedUri ?: return@setOnClickListener
            val format = if (findViewById<RadioGroup>(R.id.rgFormat).checkedRadioButtonId == R.id.rbKepub)
                OutputFormat.KEPUB else OutputFormat.EPUB

            processFile(uri, format)
        }
    }

    private fun processFile(uri: Uri, format: OutputFormat) {
        progressBar.visibility = View.VISIBLE
        btnProcess.isEnabled = false
        tvLog.text = "Procesando..."

        CoroutineScope(Dispatchers.Main).launch {
            try {
                val result = withContext(Dispatchers.IO) {
                    EpubProcessor.process(this@MainActivity, uri, format)
                }
                lastResult = result
                tvLog.text = if (result.report.fixes.isEmpty())
                    "No se encontraron problemas que arreglar."
                else
                    result.report.fixes.joinToString("\n") { "• $it" }

                progressBar.visibility = View.GONE
                btnProcess.isEnabled = true
                createDocument.launch(result.suggestedFileName)

            } catch (e: EpubStructureException) {
                progressBar.visibility = View.GONE
                btnProcess.isEnabled = true
                tvLog.text = "⚠️ ${e.message}"

            } catch (e: DrmProtectedException) {
                progressBar.visibility = View.GONE
                btnProcess.isEnabled = true
                tvLog.text = "⚠️ ${e.message}"

            } catch (e: Exception) {
                progressBar.visibility = View.GONE
                btnProcess.isEnabled = true
                tvLog.text = "⚠️ Error inesperado: ${e.message}"
            }
        }
    }

    private fun queryDisplayName(uri: Uri): String {
        var name = uri.lastPathSegment ?: "archivo.epub"
        contentResolver.query(uri, null, null, null, null)?.use { cursor ->
            val idx = cursor.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
            if (idx != -1 && cursor.moveToFirst()) {
                name = cursor.getString(idx)
            }
        }
        return name
    }
}