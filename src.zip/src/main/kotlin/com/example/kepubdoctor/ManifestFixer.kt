package com.example.kepubdoctor

import org.jsoup.Jsoup
import org.jsoup.parser.Parser
import java.io.File

object ManifestFixer {

    fun fixAll(opfFile: File, report: FixReport) {
        if (!opfFile.exists()) return
        val doc = Jsoup.parse(opfFile.readText(), "", Parser.xmlParser())
        val opfDir = opfFile.parentFile ?: return

        val manifestItems = doc.select("manifest item")
        val brokenIds = mutableListOf<String>()

        for (item in manifestItems) {
            val href = item.attr("href")
            if (href.isBlank()) continue
            val target = File(opfDir, href)
            if (!target.exists()) {
                brokenIds.add(item.attr("id"))
                item.remove()
            }
        }

        if (brokenIds.isEmpty()) return

        var spineFixed = 0
        for (id in brokenIds) {
            val itemref = doc.select("spine itemref[idref=$id]").firstOrNull()
            if (itemref != null) {
                itemref.remove()
                spineFixed++
            }
        }

        opfFile.writeText(doc.outerHtml())
        report.fixes.add(
            "${brokenIds.size} entrada(s) de manifest rota(s) eliminadas (referenciaban archivos inexistentes)" +
            if (spineFixed > 0) ", incluyendo $spineFixed del spine" else ""
        )
    }
}