package com.example.kepubdoctor

import org.jsoup.nodes.Element
import java.io.File

object EmptyContainerFixer {

    private val INVISIBLE_WHITESPACE = Regex("[\\s\\u00A0\\u200B\\u2007\\u202F\\uFEFF]")
    private val VISUAL_CONTENT_SELECTOR = "img, svg, image, video, audio, iframe, canvas"

    fun fixAll(epubDir: File, report: FixReport) {
        var totalRemoved = 0

        epubDir.walkTopDown()
            .filter { it.isFile && (it.extension == "xhtml" || it.extension == "html" || it.extension == "htm") }
            .forEach { file ->
                val original = file.readText()
                val doc = XhtmlUtils.parse(original)

                val removed = removeEmptyContainers(doc)
                totalRemoved += removed

                if (removed > 0) {
                    file.writeText(XhtmlUtils.serialize(doc))
                }
            }

        if (totalRemoved > 0) {
            report.fixes.add("$totalRemoved contenedor(es) vacíos eliminados (restos de anuncios/widgets sin contenido real que dejaban huecos en blanco)")
        }
    }

    private fun removeEmptyContainers(doc: org.jsoup.nodes.Document): Int {
        var count = 0
        var changed = true

        while (changed) {
            changed = false
            val candidates = doc.select("div, span")
                .filter { it.tagName().lowercase() != "body" }
                .sortedByDescending { it.parents().size }

            for (el in candidates) {
                if (el.parent() == null) continue
                if (el.hasClass("koboSpan")) continue
                if (isEmptyVisual(el)) {
                    el.remove()
                    count++
                    changed = true
                }
            }
        }
        return count
    }

    private fun isEmptyVisual(el: Element): Boolean {
        val text = el.text().replace(INVISIBLE_WHITESPACE, "")
        if (text.isNotEmpty()) return false
        if (el.select(VISUAL_CONTENT_SELECTOR).isNotEmpty()) return false
        return true
    }
}