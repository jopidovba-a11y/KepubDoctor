package com.example.kepubdoctor

import java.io.File

class DrmProtectedException(message: String) : Exception(message)

object DrmDetector {

    fun checkForDrm(epubDir: File) {
        val encryptionFile = File(epubDir, "META-INF/encryption.xml")
        if (encryptionFile.exists()) {
            throw DrmProtectedException(
                "Este EPUB está protegido con DRM (se detectó META-INF/encryption.xml). " +
                "KepubDoctor no puede reparar ni convertir libros con DRM."
            )
        }
        val rightsFile = File(epubDir, "META-INF/rights.xml")
        if (rightsFile.exists()) {
            throw DrmProtectedException(
                "Este EPUB está protegido con DRM (se detectó META-INF/rights.xml). " +
                "KepubDoctor no puede reparar ni convertir libros con DRM."
            )
        }
    }
}