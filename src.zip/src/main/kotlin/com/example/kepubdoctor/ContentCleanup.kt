package com.example.kepubdoctor

import java.io.File

object ContentCleanup {

    fun fixAll(epubDir: File, report: FixReport) {
        var count = 0
        epubDir.walkTopDown()
            .filter { it.isFile && (it.extension == "xhtml" || it.extension == "html" || it.extension == "htm") }
            .forEach { file ->
                val original = file.readText()
                var cleaned = original

                cleaned = cleaned.replace("\uFFFD", "")
                cleaned = cleaned.replace(Regex("</?o:p[^>]*>"), "")
                cleaned = cleaned.replace(Regex("</?w:[^>]*>"), "")
                cleaned = cleaned.replace(Regex("mso-[\\w-]+\\s*:[^;\"]*;?"), "")

                if (cleaned != original) {
                    file.writeText(cleaned)
                    count++
                }
            }
        if (count > 0) report.fixes.add("$count archivo(s) limpiados de caracteres de reemplazo Unicode y restos de MS Word")
    }
}