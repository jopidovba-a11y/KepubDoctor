package com.example.kepubdoctor

import android.content.Context
import android.net.Uri
import java.io.File

enum class OutputFormat { EPUB, KEPUB }

class EpubStructureException(message: String) : Exception(message)

data class ProcessResult(
    val report: FixReport,
    val workDir: File,
    val orderedEntries: List<String>,
    val suggestedFileName: String
)

object EpubProcessor {

    fun process(
        context: Context,
        inputUri: Uri,
        outputFormat: OutputFormat
    ): ProcessResult {
        val workDir = File(context.cacheDir, "kepubdoctor_work_${System.currentTimeMillis()}")
        workDir.mkdirs()
        val tempZipFile = File(context.cacheDir, "kepubdoctor_temp_${System.currentTimeMillis()}.zip")

        val orderedEntries: List<String>
        context.contentResolver.openInputStream(inputUri).use { input ->
            requireNotNull(input) { "No se pudo abrir el archivo" }
            orderedEntries = ZipUtils.extract(input, workDir, tempZipFile)
        }
        tempZipFile.delete()

        DrmDetector.checkForDrm(workDir)

        val report = EpubFixer.fixAll(workDir)

        if (report.fixes.any { it.startsWith("ERROR:") }) {
            throw EpubStructureException(
                "No se pudo procesar este archivo: " +
                report.fixes.first { it.startsWith("ERROR:") }
            )
        }

        val originalName = getFileName(context, inputUri) ?: "libro.epub"
        val suggestedName: String

        if (outputFormat == OutputFormat.KEPUB) {
            KepubConverter.convertAll(workDir)
            report.fixes.add("Convertido a formato KEPUB (spans de Kobo inyectados)")
            suggestedName = KepubConverter.kepubOutputFileName(originalName)
        } else {
            suggestedName = originalName.removeSuffix(".epub") + "_reparado.epub"
        }

        return ProcessResult(report, workDir, orderedEntries, suggestedName)
    }

    fun writeResult(result: ProcessResult, outputStream: java.io.OutputStream) {
        ZipUtils.repackage(result.workDir, outputStream, result.orderedEntries)
    }

    fun cleanup(result: ProcessResult) {
        result.workDir.deleteRecursively()
    }

    private fun getFileName(context: Context, uri: Uri): String? {
        var name: String? = null
        context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
            val idx = cursor.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
            if (idx != -1 && cursor.moveToFirst()) {
                name = cursor.getString(idx)
            }
        }
        return name
    }
}